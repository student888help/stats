'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import random
A=0
B=1
C=2
survival_rate = [1,1,1]
RoundOneResults = [1,1,1]
RoundTwoResults = [1,1,1]
RoundThreeResults = [1,1,1]

def Simulation(accuracy,n,simtype):
    dead = [[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
    count = [[0,0,0],[0,0,0],[0,0,0],[0,0,0]]
    for i in range(n):       
        count[0],dead[1]=TrioDuel(accuracy,count[0],n,A,simtype,dead[0])    
        count[1],dead[2]=TrioDuel(accuracy,count[1],n,B,simtype,dead[1])
        count[2],dead[3]=TrioDuel(accuracy,count[2],n,C,simtype,dead[2])
    dead[3] = [0,0,0]

    for i in range(3):
        RoundOneResults[i] = 1-count[0][i]/n
        RoundTwoResults[i] = 1-count[1][i]/n
        RoundThreeResults[i] = 1-count[2][i]/n
    survival_rate[0] = RoundOneResults
    survival_rate[1] = RoundTwoResults
    survival_rate[2] = RoundThreeResults
    
    print("Trio duel was simulated",n,"times with",simtype, "player decisions.")
    print("The chances of surviving for each player in round one is as follows:")
    print("A:",round(survival_rate[0][A],4))
    print("B:",round(survival_rate[0][B],4))
    print("C:",round(survival_rate[0][C],4))
    
    print("The chances of surviving for each player in round two is as follows:")
    print("A:",round(survival_rate[1][A],4))
    print("B:",round(survival_rate[1][B],4))
    print("C:",round(survival_rate[1][C],4))
    
    print("The chances of surviving for each player in round three is as follows:")
    print("A:",round(survival_rate[2][A],4))
    print("B:",round(survival_rate[2][B],4))
    print("C:",round(survival_rate[2][C],4))
    
    print("-------------------------------------------------------------------")
    
def maximum(a, b):                    
    if a >= b:
        return a 
    else: 
        return b 
  
   
def TrioDuel(player,count,n,rnd,simtype,dead):
    choice = [None]*3
    valid = False
    
    
    
    playeracc = [None]*3
    playeracc[A] = ['hit']*3.3 + ['miss']*6.7
    playeracc[B] = ['hit']*6.7 + ['miss']*3.3 
    playeracc[C] = ['hit']*1.0 + ['miss']*0.0
    willDie=list(dead)
   
    player_hm = [None]*3 
 
    if simtype == 'random':
        while valid == False:
            choice = list(player)                          
            choiceshuffle = list(player)
            for i in range(3):
                while choice[i]==player[i]:
                    random.shuffle(choiceshuffle)
                    choice[i] = choiceshuffle[i]
                    random.shuffle(choiceshuffle)
                    choice[i-1] = choiceshuffle[i]
                    random.shuffle(choiceshuffle)
                    choice[i-2] = choiceshuffle[i]
            if choice[0]!=player[0] and choice[1]!=player[1] and choice[2]!=player[2]:
                valid = True
    elif simtype == 'optimal':
        if rnd==1:
            player = ['0.15','0.20','1.00']
        if rnd==2:
            player = ['0.15','0.10','0.06']
        choice[A] = maximum(player[1],player[2])       
        choice[B] = maximum(player[0],player[2])
        choice[C] = maximum(player[0],player[1])
            
    for i in range(3):
        random.shuffle(playeracc[i])
        player_hm[i] = playeracc[i][0]
        for j in range(3):
                if choice[i] == player[j]:
                    if dead[j] == 0 and dead[i] == 0:
                        if player_hm[i] == 'hit':
                            count[j]+=1
                            willDie[j]=1
        if dead[i] != 0:
            count[i]+=1
    for i in range(2,0,-1):
        for j in range(3):
            if dead[j] == 0 and dead[i] == 0:
                if choice[i] == choice[i-1]:
                    if player_hm[i] == 'hit' and player_hm[i-1] == 'hit':
                        if choice[i]==player[j]:
                            if player_hm[i] == 'hit':
                                hit=1
                                count[j]-=1
            elif dead[j] == 0 and dead[i] == 0:
                if choice[i] == choice[i-2]:
                    if player_hm[i] == 'hit' and player_hm[i-2] == 'hit':
                        if choice[i]==player[j]:
                            if player_hm[i] == 'hit' and hit!=1:
                                count[j]-=1
    dead = willDie
    return count, dead
    
accuracy = ['0.33','0.67','1.0']         
trials = 10000
Simulation(accuracy,trials,'random')
Simulation(accuracy,trials,'optimal')